package com.example.tiffinmate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class UpdateMenu extends AppCompatActivity {

    private TextInputEditText foodName, foodPrice, foodDescription;
    private Button saveButton, addFood, cancelButton;
    private CardView popup;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_menu);

        // Initialize views
        foodName = findViewById(R.id.etFoodName);
        foodPrice = findViewById(R.id.etFoodPrice);
        foodDescription = findViewById(R.id.etFoodDescription);
        saveButton = findViewById(R.id.btnSubmit);
        addFood = findViewById(R.id.addFood);
        cancelButton = findViewById(R.id.btnCancel);
        popup = findViewById(R.id.cardViewPopup);

        db = FirebaseFirestore.getInstance();

        // Add Food button click - show popup
        addFood.setOnClickListener(v -> popup.setVisibility(View.VISIBLE));

        // Cancel button click - hide popup
        cancelButton.setOnClickListener(v -> {
            popup.setVisibility(View.GONE);
            clearForm();
        });

        // Save button click - save to Firestore
        saveButton.setOnClickListener(v -> saveFoodToFirestore());
    }

    private void saveFoodToFirestore() {
        String name = foodName.getText().toString().trim();
        String price = foodPrice.getText().toString().trim();
        String description = foodDescription.getText().toString().trim();

        if (name.isEmpty() || price.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show loading state
        saveButton.setEnabled(false);
        saveButton.setText("Saving...");

        Map<String, Object> food = new HashMap<>();
        food.put("name", name);
        food.put("price", price);
        food.put("description", description);
        food.put("timestamp", Timestamp.now()); // Add server timestamp

        db.collection("foods").add(food)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(this, "Food added successfully", Toast.LENGTH_SHORT).show();
                    clearForm();
                    popup.setVisibility(View.GONE);

                    // Navigate to subscription activity after successful save
                    navigateToSubscription();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    saveButton.setEnabled(true);
                    saveButton.setText("Submit");
                });
    }

    private void navigateToSubscription() {
        startActivity(new Intent(UpdateMenu.this, suscribtionadmin.class));
        finish();
    }

    private void clearForm() {
        foodName.setText("");
        foodPrice.setText("");
        foodDescription.setText("");
        saveButton.setEnabled(true);
        saveButton.setText("Submit");
    }
}