package com.example.tiffinmate;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import com.airbnb.lottie.LottieAnimationView;

public class screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen);

        LottieAnimationView lottieAnimationView = findViewById(R.id.lottieAnimation);

        lottieAnimationView.addAnimatorUpdateListener(animation -> {
        });

        new Handler().postDelayed(() -> {
            Intent intent = new Intent(screen.this, AdminLogin.class);
            startActivity(intent);
            finish();
        }, 3000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LottieAnimationView lottieAnimationView = findViewById(R.id.lottieAnimation);
        if (lottieAnimationView != null) {
            lottieAnimationView.cancelAnimation();
        }
    }
}