package com.example.tiffinmate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class usersub extends AppCompatActivity {

    private TextView titleTextView, subidTextView, descriptionTextView,
            priceTextView, timestampTextView;
    private Button confirmButton;
    private CardView subscriptionCard;
    private FirebaseFirestore db;
    private ListenerRegistration subscriptionListener;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_usersub);

        // Initialize views
        titleTextView = findViewById(R.id.titleTextView);
        subidTextView = findViewById(R.id.subidTextView);
        descriptionTextView = findViewById(R.id.descriptionTextView);
        priceTextView = findViewById(R.id.priceTextView);
        confirmButton = findViewById(R.id.confirmButton);
        subscriptionCard = findViewById(R.id.subscriptionCard);

        // Add this line to your XML layout first (see below)
        timestampTextView = findViewById(R.id.timestampt);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Set up confirm button
        confirmButton.setOnClickListener(v -> {
            Toast.makeText(this, "Subscription Confirmed!", Toast.LENGTH_SHORT).show();
            finish();
        });

        // Set up window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Load subscription data
        loadSubscriptionData();
    }

    private void loadSubscriptionData() {
        // Get the most recent subscription
        subscriptionListener = db.collection("subscriptions")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(1)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Toast.makeText(this, "Error loading subscription", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (value != null && !value.isEmpty()) {
                        DocumentSnapshot document = value.getDocuments().get(0);
                        updateSubscriptionUI(document);
                        subscriptionCard.setVisibility(View.VISIBLE);
                    } else {
                        subscriptionCard.setVisibility(View.GONE);
                        Toast.makeText(this, "No subscriptions available", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void updateSubscriptionUI(DocumentSnapshot document) {
        // Get data from document
        String title = document.getString("title");
        String subid = document.getString("subid");
        String description = document.getString("description");
        Double price = document.getDouble("price");
        Timestamp timestamp = document.getTimestamp("timestamp");

        // Format timestamp
        String formattedDate = "Not available";
        if (timestamp != null) {
            Date date = timestamp.toDate();
            formattedDate = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                    .format(date);
        }

        // Update UI
        titleTextView.setText(title != null ? title : "No Title");
        subidTextView.setText(subid != null ? "ID: " + subid : "No ID");
        descriptionTextView.setText(description != null ? description : "No Description");
        priceTextView.setText(price != null ? String.format("Price: ₹%.2f", price) : "Price: N/A");
        timestampTextView.setText("Created: " + formattedDate);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove the Firestore listener when activity is destroyed
        if (subscriptionListener != null) {
            subscriptionListener.remove();
        }
    }
}