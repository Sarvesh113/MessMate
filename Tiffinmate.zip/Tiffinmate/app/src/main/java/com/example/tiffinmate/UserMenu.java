package com.example.tiffinmate;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UserMenu extends AppCompatActivity {
    private LinearLayout foodContainer;
    private Button subscriptionButton;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_menu);

        // Initialize views
        foodContainer = findViewById(R.id.foodContainer);
        subscriptionButton = new Button(this);
        subscriptionButton.setText("Subscribe Now");
        subscriptionButton.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        subscriptionButton.setOnClickListener(v -> {
            startActivity(new Intent(UserMenu.this, usersub.class));
        });


        db = FirebaseFirestore.getInstance();


        fetchFoodItems();
    }

    private void fetchFoodItems() {
        db.collection("foods")
                .orderBy("timestamp", Query.Direction.DESCENDING) // Sort by timestamp descending
                .limit(7) // Only get 7 most recent items
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        // Handle error
                        return;
                    }

                    // Clear existing views
                    foodContainer.removeAllViews();

                    if (value != null && !value.isEmpty()) {
                        for (QueryDocumentSnapshot document : value) {
                            // Inflate card view for each food item
                            View cardView = LayoutInflater.from(this)
                                    .inflate(R.layout.food_item_card, foodContainer, false);

                            // Get references to views in the card
                            TextView tvFoodName = cardView.findViewById(R.id.tvFoodName);
                            TextView tvFoodPrice = cardView.findViewById(R.id.tvFoodPrice);
                            TextView tvFoodDescription = cardView.findViewById(R.id.tvFoodDescription);
                            TextView tvTimestamp = cardView.findViewById(R.id.tvTimestamp);


                            tvFoodName.setText(document.getString("name"));
                            tvFoodPrice.setText("₹" + document.getString("price"));
                            tvFoodDescription.setText(document.getString("description"));


                            if (document.getTimestamp("timestamp") != null) {
                                Date date = document.getTimestamp("timestamp").toDate();
                                String formattedDate = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                                        .format(date);
                                tvTimestamp.setText("Added: " + formattedDate);
                            }


                            foodContainer.addView(cardView);
                        }


                        foodContainer.addView(subscriptionButton);
                    }
                });
    }
}