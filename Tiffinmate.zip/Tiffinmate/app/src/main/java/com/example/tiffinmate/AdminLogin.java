package com.example.tiffinmate;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class AdminLogin extends AppCompatActivity {
    private TextInputEditText emailEditText, passwordEditText;
    private TextInputLayout emailInputLayout, passwordInputLayout;

    // Credentials
    private static final String USER_EMAIL = "sarveshgotmare9@gmail.com";
    private static final String USER_PASSWORD = "pass@123";
    private static final String ADMIN_EMAIL = "sarveshgotmare10@gmail.com";
    private static final String ADMIN_PASSWORD = "pass@1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_login);

        // Initialize views
        emailInputLayout = findViewById(R.id.emailInputLayout);
        passwordInputLayout = findViewById(R.id.passwordInputLayout);
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        // Set click listener
        View loginButton = findViewById(R.id.login_button);
        if (loginButton != null) {
            loginButton.setOnClickListener(v -> validateLoginForm());
        } else {
            throw new RuntimeException("Login button not found in layout!");
        }

        // Edge-to-edge (optional)
        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private boolean validateLoginForm() {
        // Reset errors
        emailInputLayout.setError(null);
        passwordInputLayout.setError(null);

        // Get values
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        boolean isValid = true;

        // Email validation
        if (email.isEmpty()) {
            emailInputLayout.setError("Email is required");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInputLayout.setError("Please enter a valid email");
            isValid = false;
        }

        // Password validation
        if (password.isEmpty()) {
            passwordInputLayout.setError("Password is required");
            isValid = false;
        } else if (password.length() < 6) {
            passwordInputLayout.setError("Password must be at least 6 characters");
            isValid = false;
        } else if (password.length() > 20) {
            passwordInputLayout.setError("Password too long");
            isValid = false;
        }

        if (isValid) {
            // Check credentials
            if (email.equals(USER_EMAIL)){
                if (password.equals(USER_PASSWORD)) {
                    // User login successful
                    Intent intent = new Intent(this, UserLocationActivity.class);
                    startActivity(intent);
                    finish(); // Optional: close login activity
                } else {
                    passwordInputLayout.setError("Incorrect password");
                    Toast.makeText(this, "Please enter valid credentials", Toast.LENGTH_SHORT).show();
                    isValid = false;
                }
            } else if (email.equals(ADMIN_EMAIL)) {
                if (password.equals(ADMIN_PASSWORD)) {
                    // Admin login successful
                    Intent intent = new Intent(this, AdminLocationActivity.class);
                    startActivity(intent);
                    finish(); // Optional: close login activity
                } else {
                    passwordInputLayout.setError("Incorrect password");
                    Toast.makeText(this, "Please enter valid credentials", Toast.LENGTH_SHORT).show();
                    isValid = false;
                }
            } else {
                emailInputLayout.setError("Email not recognized");
                Toast.makeText(this, "Please enter valid credentials", Toast.LENGTH_SHORT).show();
                isValid = false;
            }
        }

        return isValid;
    }
}